# Marketing-Campaign-Performance
This contains the code files for the Marketing Campaign Performance project linked on my portfolio websites. You can access the Tableau dashboard here: https://public.tableau.com/app/profile/jabulile.shongwe/viz/MarketingCampaignPerformance_16987350819450/Dashboard1

The original Marketing Campaign dataset was sourced from Kaggle and can be accessed on the following link:https://www.kaggle.com/datasets/manishabhatt22/marketing-campaign-performance-dataset

